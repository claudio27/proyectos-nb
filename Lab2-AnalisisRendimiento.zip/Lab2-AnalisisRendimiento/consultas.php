<?php

$con=mysql_connect("localhost","root","nube123");

mysql_select_db("prueba",$con);


$consulta = "select * from persona";

$resp = mysql_query($consulta,$con ) or die(mysql_error());

$result = mysql_num_rows($resp);


    if ($result > 0) {
       while ($rowEmp = mysql_fetch_assoc($resp)) {
          echo "".$rowEmp['idpersona']."\n";
          echo "".$rowEmp['nombre']."\n";
          echo "".$rowEmp['apellido']."\n";
       }
    }




?>
