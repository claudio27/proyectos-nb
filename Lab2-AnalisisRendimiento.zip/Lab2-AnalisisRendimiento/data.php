<?php

    /*
http://www.lacorona.com.mx/fortiz/adodb/tute-es.htm

http://adodb.sourceforge.net/#download

mysql -u root -p

create database
    -> clientes;
use clientes;
create table persona(idpersona int, nombre varchar(15), apellido varchar(15));
 create table dueno(id_auto int, id_persona int);
create table auto(id_auto int, marca varchar(15), modelo varchar(15));


insert into persona values(1,"hfasdf","fasddasf");
insert into dueno values(1,1);
insert into auto values(1,"marca","modlers");


*/


        // mysql -u DBUSER -h DBSERVERNAME -p 
?>
